//Author : Rudiyanto
//17 September 2018
//Program Hitung Luas dan Volume
//Class View Limas

package volumedanluasbangun;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

public class ViewLimas extends JFrame{
    MLimas limas = new MLimas();
    
    JLabel llimas, lalas, ltinggiSegitiga, ltinggi, lvolume, lluas;
    JTextField falas, ftinggiSegitiga, ftinggi, fluas, fvolume;
    JButton btnKembali, btnHitung;
    
    public ViewLimas(){
        setTitle("Limas");
        setDefaultCloseOperation(3);
        setLayout(null);
        setSize(250, 340);
        setLocationRelativeTo(null);
        setVisible(true);
        setResizable(false);
        
        llimas = new JLabel("Limas Segitiga");
        add(llimas).setBounds(70, 20, 130, 20);
        llimas.setFont(new Font("Quicksand Light", 1, 16));
        
        lalas = new JLabel("Alas Segitiga");
        add(lalas).setBounds(20, 60, 100, 20);
        falas = new JTextField(10);
        add(falas).setBounds(100, 60, 120, 20);
        
        ltinggiSegitiga = new JLabel("Tinggi");
        add(ltinggiSegitiga).setBounds(20, 85, 100, 20);
        ftinggiSegitiga = new JTextField(10);
        add(ftinggiSegitiga).setBounds(100, 85, 120, 20);
        
        ltinggi = new JLabel("Tinggi Limas");
        add(ltinggi).setBounds(20, 110, 100, 20);
        ftinggi = new JTextField(10);
        add(ftinggi).setBounds(100, 110, 120, 20);
        
        btnHitung = new JButton("Hitung");
        add(btnHitung).setBounds(70, 150, 100, 20);
        
        lluas = new JLabel("Luas");
        add(lluas).setBounds(20, 200, 100, 20);
        fluas = new JTextField(10);
        add(fluas).setBounds(100, 200, 120, 20);
        
        lvolume = new JLabel("Volume");
        add(lvolume).setBounds(20, 225, 100, 20);
        fvolume = new JTextField(10);
        add(fvolume).setBounds(100, 225, 120, 20);
        
        btnKembali = new JButton("Kembali");
        add(btnKembali).setBounds(70, 270, 100, 20);
        
        btnHitung.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                float alas = Float.parseFloat(falas.getText());
                float tinggiSegitiga = Float.parseFloat(ftinggiSegitiga.getText());
                float tinggi = Float.parseFloat(ftinggi.getText());
                limas.setAlas(alas);
                limas.setTinggiSegitiga(tinggiSegitiga);
                limas.setTinggi(tinggi);
                limas.setLuas(alas, tinggiSegitiga, tinggi);
                limas.setVolume(alas, tinggiSegitiga, tinggi);
                
                String luas = Float.toString(limas.getLuas());
                String volume = Float.toString(limas.getVolume());
                fluas.setText(luas);
                fvolume.setText(volume);
            }
        });
        
        btnKembali.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new ViewUtama();
                dispose();
            }
        });
    }
}
