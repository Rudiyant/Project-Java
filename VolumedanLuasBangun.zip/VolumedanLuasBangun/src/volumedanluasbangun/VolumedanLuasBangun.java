//Author : Rudiyanto
//17 September 2018
//Program Hitung Luas dan Volume
//Main class

package volumedanluasbangun;

public class VolumedanLuasBangun {

    public static void main(String[] args) {
        new ViewUtama();
    }  
}
