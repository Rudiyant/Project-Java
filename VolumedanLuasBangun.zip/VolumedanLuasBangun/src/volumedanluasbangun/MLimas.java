//Author : Rudiyanto
//17 September 2018
//Program Hitung Luas dan Volume
//Class Model Limas

package volumedanluasbangun;

public class MLimas {
    float alas, tinggiSegitiga, tinggi, luas, volume;

    public float getAlas() {
        return alas;
    }

    public void setAlas(float alas) {
        this.alas = alas;
    }

    public float getTinggiSegitiga() {
        return tinggiSegitiga;
    }

    public void setTinggiSegitiga(float tinggiSegitiga) {
        this.tinggiSegitiga = tinggiSegitiga;
    }

    public float getTinggi() {
        return tinggi;
    }

    public void setTinggi(float tinggi) {
        this.tinggi = tinggi;
    }

    public float getLuas() {
        return luas;
    }

    public void setLuas(float alas, float tinggiSegitiga, float tinggi) {
        this.luas = (float) ((alas*tinggiSegitiga)/2 + 3*((Math.sqrt(((alas/2)*(alas/2))+(tinggi*tinggi))*alas/2)));
    }

    public float getVolume() {
        return volume;
    }

    public void setVolume(float alas, float tinggiSegitiga, float tinggi) {
        this.volume = (alas*tinggiSegitiga*tinggi)/6;
    }
}
