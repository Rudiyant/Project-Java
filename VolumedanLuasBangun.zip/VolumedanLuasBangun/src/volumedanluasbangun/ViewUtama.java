//Author : Rudiyanto
//17 September 2018
//Program Hitung Luas dan Volume
//Class View Utama

package volumedanluasbangun;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

public class ViewUtama extends JFrame {
    JLabel ljudul;
    JButton btnLimas, btnKerucut, btnBalok;
    
    public ViewUtama(){
        setTitle("Hitung Luas dan Volume");
        setDefaultCloseOperation(3);
        setLayout(null);
        setSize(240, 190);
        setLocationRelativeTo(null);
        setVisible(true);
        setResizable(false);
        
        ljudul = new JLabel("Hitung Luas dan Volume");
        add(ljudul).setBounds(20, 20, 220, 20);
        ljudul.setFont(new Font("Quicksand Light", 1, 16));
        
        btnLimas = new JButton("Limas Segitiga");
        add(btnLimas).setBounds(50, 60, 130, 20);
        
        btnKerucut = new JButton("Kerucut");
        add(btnKerucut).setBounds(50, 90, 130, 20);
        
        btnBalok = new JButton("Balok");
        add(btnBalok).setBounds(50, 120, 130, 20);
        
        btnLimas.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new ViewLimas();
                dispose();
            }
        });
        
        btnKerucut.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new ViewKerucut();
                dispose();
            }
        });
        
        btnBalok.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new ViewBalok();
                dispose();
            }
        });
    }
}
