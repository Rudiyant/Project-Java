//Author : Rudiyanto
//17 September 2018
//Program Hitung Luas dan Volume
//Class Model Balok

package volumedanluasbangun;

public class MBalok {
    float panjang, lebar, tinggi, luas, volume;

    public float getPanjang() {
        return panjang;
    }

    public void setPanjang(float panjang) {
        this.panjang = panjang;
    }

    public float getLebar() {
        return lebar;
    }

    public void setLebar(float lebar) {
        this.lebar = lebar;
    }

    public float getTinggi() {
        return tinggi;
    }

    public void setTinggi(float tinggi) {
        this.tinggi = tinggi;
    }

    public float getLuas() {
        return luas;
    }

    public void setLuas(float panjang, float lebar, float tinggi) {
        this.luas = 2*((panjang*lebar) + (panjang*tinggi) + (lebar*tinggi));
    }

    public float getVolume() {
        return volume;
    }

    public void setVolume(float panjang, float lebar, float tinggi) {
        this.volume = panjang*lebar*tinggi;
    }
}
