//Author : Rudiyanto
//17 September 2018
//Program Hitung Luas dan Volume
//Class View Balok

package volumedanluasbangun;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

public class ViewBalok extends JFrame{
    MBalok balok = new MBalok();
    
    JLabel lbalok, lpanjang, llebar, ltinggi, lvolume, lluas;
    JTextField fpanjang, flebar, ftinggi, fluas, fvolume;
    JButton btnKembali, btnHitung;
    
    public ViewBalok(){
        setTitle("Balok");
        setDefaultCloseOperation(3);
        setLayout(null);
        setSize(250, 340);
        setLocationRelativeTo(null);
        setVisible(true);
        setResizable(false);
        
        lbalok = new JLabel("Balok");
        add(lbalok).setBounds(90, 20, 80, 20);
        lbalok.setFont(new Font("Quicksand Light", 1, 16));
        
        lpanjang = new JLabel("Panjang");
        add(lpanjang).setBounds(20, 60, 100, 20);
        fpanjang = new JTextField(10);
        add(fpanjang).setBounds(100, 60, 120, 20);
        
        llebar = new JLabel("Lebar");
        add(llebar).setBounds(20, 85, 100, 20);
        flebar = new JTextField(10);
        add(flebar).setBounds(100, 85, 120, 20);
        
        ltinggi = new JLabel("Tinggi");
        add(ltinggi).setBounds(20, 110, 100, 20);
        ftinggi = new JTextField(10);
        add(ftinggi).setBounds(100, 110, 120, 20);
        
        btnHitung = new JButton("Hitung");
        add(btnHitung).setBounds(70, 150, 100, 20);
        
        lluas = new JLabel("Luas");
        add(lluas).setBounds(20, 200, 100, 20);
        fluas = new JTextField(10);
        add(fluas).setBounds(100, 200, 120, 20);
        
        lvolume = new JLabel("Volume");
        add(lvolume).setBounds(20, 225, 100, 20);
        fvolume = new JTextField(10);
        add(fvolume).setBounds(100, 225, 120, 20);
        
        btnKembali = new JButton("Kembali");
        add(btnKembali).setBounds(70, 270, 100, 20);
        
        btnHitung.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                float lebar = Float.parseFloat(flebar.getText());
                float panjang = Float.parseFloat(fpanjang.getText());
                float tinggi = Float.parseFloat(ftinggi.getText());
                balok.setLebar(lebar);
                balok.setPanjang(panjang);
                balok.setTinggi(tinggi);
                balok.setLuas(panjang, lebar, tinggi);
                balok.setVolume(panjang, lebar, tinggi);
                
                String luas = Float.toString(balok.getLuas());
                String volume = Float.toString(balok.getVolume());
                fluas.setText(luas);
                fvolume.setText(volume);
            }
        });
        
        btnKembali.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new ViewUtama();
                dispose();
            }
        });
    }
}
