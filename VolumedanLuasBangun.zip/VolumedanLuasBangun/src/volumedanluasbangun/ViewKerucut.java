//Author : Rudiyanto
//17 September 2018
//Program Hitung Luas dan Volume
//Class View Kerucut

package volumedanluasbangun;

import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

public class ViewKerucut extends JFrame{
    MKerucut kerucut = new MKerucut();
    
    JLabel lkerucut, ljarijari, lselimut, ltinggi, lvolume, lluas;
    JTextField fjarijari, fselimut, ftinggi, fluas, fvolume;
    JButton btnKembali, btnHitung;
    
    public ViewKerucut(){
        setTitle("Kerucut");
        setDefaultCloseOperation(3);
        setLayout(null);
        setSize(250, 340);
        setLocationRelativeTo(null);
        setVisible(true);
        setResizable(false);
        
        lkerucut = new JLabel("Kerucut");
        add(lkerucut).setBounds(90, 20, 80, 20);
        lkerucut.setFont(new Font("Quicksand Light", 1, 16));
        
        ljarijari = new JLabel("Jari-jari");
        add(ljarijari).setBounds(20, 60, 100, 20);
        fjarijari = new JTextField(10);
        add(fjarijari).setBounds(100, 60, 120, 20);
        
        lselimut = new JLabel("Pelukis");
        add(lselimut).setBounds(20, 85, 100, 20);
        fselimut = new JTextField(10);
        add(fselimut).setBounds(100, 85, 120, 20);
        
        ltinggi = new JLabel("Tinggi");
        add(ltinggi).setBounds(20, 110, 100, 20);
        ftinggi = new JTextField(10);
        add(ftinggi).setBounds(100, 110, 120, 20);
        
        btnHitung = new JButton("Hitung");
        add(btnHitung).setBounds(70, 150, 100, 20);
        
        lluas = new JLabel("Luas");
        add(lluas).setBounds(20, 200, 100, 20);
        fluas = new JTextField(10);
        add(fluas).setBounds(100, 200, 120, 20);
        
        lvolume = new JLabel("Volume");
        add(lvolume).setBounds(20, 225, 100, 20);
        fvolume = new JTextField(10);
        add(fvolume).setBounds(100, 225, 120, 20);
        
        btnKembali = new JButton("Kembali");
        add(btnKembali).setBounds(70, 270, 100, 20);
        
        btnHitung.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                float jarijari = Float.parseFloat(fjarijari.getText());
                float selimut = Float.parseFloat(fselimut.getText());
                float tinggi = Float.parseFloat(ftinggi.getText());
                kerucut.setJarijari(jarijari);
                kerucut.setSelimut(selimut);
                kerucut.setTinggi(tinggi);
                kerucut.setLuas(jarijari, selimut);
                kerucut.setVolume(jarijari, tinggi);
                
                String luas = Float.toString(kerucut.getLuas());
                String volume = Float.toString(kerucut.getVolume());
                fluas.setText(luas);
                fvolume.setText(volume);
            }
        });
        
        btnKembali.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                new ViewUtama();
                dispose();
            }
        });
    }
}
