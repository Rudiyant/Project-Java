//Author : Rudiyanto
//17 September 2018
//Program Hitung Luas dan Volume
//Class Model Kerucut

package volumedanluasbangun;

public class MKerucut {
    float jarijari, selimut, tinggi, luas, volume;

    public float getJarijari() {
        return jarijari;
    }

    public void setJarijari(float jarijari) {
        this.jarijari = jarijari;
    }

    public float getSelimut() {
        return selimut;
    }

    public void setSelimut(float selimut) {
        this.selimut = selimut;
    }

    public float getTinggi() {
        return tinggi;
    }

    public void setTinggi(float tinggi) {
        this.tinggi = tinggi;
    }

    public float getLuas() {
        return luas;
    }

    public void setLuas(float jarijari, float selimut) {
        this.luas = (float) ((3.14*jarijari*jarijari) + (3.14*jarijari*selimut));
    }

    public float getVolume() {
        return volume;
    }

    public void setVolume(float jarijari, float tinggi) {
        this.volume = (float) (3.14*jarijari*jarijari*tinggi/3);
    }
}
